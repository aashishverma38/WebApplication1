﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Flickr.Photos
{
    public partial class Sets1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (! Page.IsPostBack)
            {
                DatabaseHandler dbh = new DatabaseHandler();
                List<String> photonames = dbh.getDropDownNames(Session["currUser"].ToString());
                for (int i = 0; i < photonames.Count; i++)
                {
                    photonamesDropDown.Items.Add(photonames[i]);
                }
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                String photopath = null;

                DatabaseHandler dbh = new DatabaseHandler();
                String photoname = photonamesDropDown.Text;
                photopath = dbh.getUserCoverPhoto(Session["currUser"].ToString(), photoname);



                coverphoto.ImageUrl = photopath;
            
            //Response.Redirect("Set1.aspx",true);
        }
    }
}