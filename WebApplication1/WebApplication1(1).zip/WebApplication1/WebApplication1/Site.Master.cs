﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Flickr
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["currUser"] == null)
            {
                NavigationMenuCommon.Visible = true;
                NavigationMenuUser.Visible = false;
            }
            else
            {
                NavigationMenuCommon.Visible = false;
                NavigationMenuUser.Visible = true;
            }
        }

        protected void lnkbtnLogout_Click(object sender, EventArgs e)
        {
            Session["currUser"] = null;
            Response.Redirect("~/Default.aspx");
        }
    }
}

